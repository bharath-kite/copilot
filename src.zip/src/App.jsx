import Home from "./Components/Home"

const App = ()=>{
    return(
        <div>
            <Home/>
        </div>
    )
}
export default App